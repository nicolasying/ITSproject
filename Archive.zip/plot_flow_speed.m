function [] = plot_flow_speed( matrix )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
plot(matrix(:,2),matrix(:,3));

end

